"""
VERDICT WEIGHT™ Synthetic Validation Engine
============================================
Author: Odingard Security / Six Sense Enterprise Services
Framework: VERDICT WEIGHT™ v2.1
Purpose: Synthetic validation for arXiv cs.CR submission

VERDICT WEIGHT™ is a proprietary multi-source confidence synthesis framework
for autonomous cybersecurity intelligence systems. This script generates a
controlled synthetic dataset and validates the framework against two baselines.

Four Evidence Streams:
  1. Source Reliability (SR)       — credibility of the originating source
  2. Cross-Feed Corroboration (CC) — independent confirmation across feeds
  3. Temporal Decay (TD)           — recency of the intelligence signal
  4. Historical Source Accuracy (HA) — track record of this source

Three Output Components:
  1. Signal Strength (SS)      — confidence the threat is real (0.0–1.0)
  2. Doubt Index (DI)          — internal inconsistency across streams (0.0–1.0)
  3. Consequence Weight (CW)   — actionability score accounting for doubt (0.0–1.0)
"""

import numpy as np
import pandas as pd
from sklearn.metrics import (
    brier_score_loss, roc_auc_score, precision_score,
    recall_score, f1_score, average_precision_score
)
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import matplotlib.gridspec as gridspec
from scipy.stats import pearsonr
import warnings
warnings.filterwarnings('ignore')

np.random.seed(42)

# ─────────────────────────────────────────────
# VERDICT WEIGHT™ ALGORITHM
# ─────────────────────────────────────────────

# Stream weights (sum to 1.0)
W_SR = 0.35   # Source Reliability — highest weight, foundational
W_CC = 0.25   # Cross-Feed Corroboration
W_TD = 0.20   # Temporal Decay
W_HA = 0.20   # Historical Source Accuracy

TEMPORAL_DECAY_LAMBDA = 0.05   # Halves every ~14 days
DOUBT_PENALTY         = 0.30   # How much doubt reduces consequence weight


def temporal_decay(age_days: np.ndarray) -> np.ndarray:
    """Exponential decay function. Fresh intel = 1.0, decays toward 0."""
    return np.exp(-TEMPORAL_DECAY_LAMBDA * age_days)


def corroboration_score(n_sources: np.ndarray) -> np.ndarray:
    """
    Saturation function. Zero independent sources = 0.10 floor.
    Each additional source adds diminishing confidence.
    """
    return 1.0 - np.exp(-0.55 * n_sources)


def signal_strength(SR, CC, TD, HA) -> np.ndarray:
    """
    VERDICT WEIGHT™ Signal Strength.
    Weighted geometric mean — penalizes weak streams more aggressively
    than arithmetic mean. One weak stream cannot be masked by others.
    """
    epsilon = 1e-9
    SS = (
        (SR + epsilon) ** W_SR *
        (CC + epsilon) ** W_CC *
        (TD + epsilon) ** W_TD *
        (HA + epsilon) ** W_HA
    )
    return np.clip(SS, 0.0, 1.0)


def doubt_index(SR, CC, TD, HA) -> np.ndarray:
    """
    VERDICT WEIGHT™ Doubt Index.
    Coefficient of variation across the four streams.
    High inter-stream disagreement = high doubt.
    """
    streams = np.stack([SR, CC, TD, HA], axis=1)
    mean = np.mean(streams, axis=1)
    std  = np.std(streams, axis=1)
    DI   = np.where(mean > 1e-9, std / mean, 1.0)
    # Normalize: CV typically 0–1 in this domain
    DI   = np.clip(DI / 1.0, 0.0, 1.0)
    return DI


def consequence_weight(SS, DI) -> np.ndarray:
    """
    VERDICT WEIGHT™ Consequence Weight.
    Actionability score. High doubt discounts signal strength.
    """
    CW = SS * (1.0 - DOUBT_PENALTY * DI)
    return np.clip(CW, 0.0, 1.0)


def verdict_weight(SR, CC, TD, HA):
    """Full VERDICT WEIGHT™ pipeline. Returns SS, DI, CW."""
    SS = signal_strength(SR, CC, TD, HA)
    DI = doubt_index(SR, CC, TD, HA)
    CW = consequence_weight(SS, DI)
    return SS, DI, CW


# ─────────────────────────────────────────────
# BASELINE METHODS
# ─────────────────────────────────────────────

def baseline_equal_weight(SR, CC, TD, HA) -> np.ndarray:
    """Baseline A: Arithmetic mean with equal weights."""
    return (SR + CC + TD + HA) / 4.0


def baseline_single_source(SR) -> np.ndarray:
    """Baseline B: Source reliability only (common naive approach)."""
    return SR


# ─────────────────────────────────────────────
# SYNTHETIC DATASET GENERATOR
# ─────────────────────────────────────────────

def generate_synthetic_dataset(n: int = 1000) -> pd.DataFrame:
    """
    Generate N controlled synthetic intelligence scenarios.

    Ground truth assignment mirrors real-world intelligence reliability:
      - HIGH confidence profile  (all streams >0.65): 88% true positive rate
      - MEDIUM confidence profile (streams 0.35–0.70): 58% true positive rate
      - LOW confidence profile   (all streams <0.45): 18% true positive rate
      - ADVERSARIAL profile (high SR, low CC):        35% true positive rate
      - STALE profile (high SR/CC, low TD):           50% true positive rate

    Profile distribution reflects operational intelligence feed composition.
    """
    profiles = {
        'HIGH':        int(n * 0.25),
        'MEDIUM':      int(n * 0.30),
        'LOW':         int(n * 0.20),
        'ADVERSARIAL': int(n * 0.15),
        'STALE':       int(n * 0.10),
    }
    # Remainder goes to MEDIUM
    profiles['MEDIUM'] += n - sum(profiles.values())

    rows = []

    for profile, count in profiles.items():
        for _ in range(count):

            if profile == 'HIGH':
                sr = np.random.beta(9, 2)
                age_days = np.random.exponential(3)
                n_src = np.random.randint(3, 8)
                ha = np.random.beta(8, 2)
                true_prob = 0.88

            elif profile == 'MEDIUM':
                sr = np.random.beta(4, 3)
                age_days = np.random.exponential(10)
                n_src = np.random.randint(1, 5)
                ha = np.random.beta(4, 3)
                true_prob = 0.58

            elif profile == 'LOW':
                sr = np.random.beta(2, 6)
                age_days = np.random.exponential(25)
                n_src = np.random.randint(0, 3)
                ha = np.random.beta(2, 5)
                true_prob = 0.18

            elif profile == 'ADVERSARIAL':
                # High source reliability but low corroboration — spoofed intel
                sr = np.random.beta(8, 2)
                age_days = np.random.exponential(5)
                n_src = np.random.randint(0, 2)
                ha = np.random.beta(3, 4)
                true_prob = 0.35

            else:  # STALE
                sr = np.random.beta(7, 2)
                age_days = np.random.exponential(45)
                n_src = np.random.randint(2, 6)
                ha = np.random.beta(7, 2)
                true_prob = 0.50

            td = temporal_decay(np.array([age_days]))[0]
            cc = corroboration_score(np.array([n_src]))[0]
            ground_truth = int(np.random.random() < true_prob)

            rows.append({
                'profile':     profile,
                'SR':          np.clip(sr, 0.01, 0.99),
                'CC':          np.clip(cc, 0.01, 0.99),
                'TD':          np.clip(td, 0.01, 0.99),
                'HA':          np.clip(ha, 0.01, 0.99),
                'age_days':    age_days,
                'n_sources':   n_src,
                'ground_truth': ground_truth,
                'true_prob':   true_prob,
            })

    df = pd.DataFrame(rows).sample(frac=1, random_state=42).reset_index(drop=True)
    return df


# ─────────────────────────────────────────────
# EVALUATION
# ─────────────────────────────────────────────

def evaluate(y_true, y_score, name: str, threshold: float = 0.5) -> dict:
    y_pred = (y_score >= threshold).astype(int)
    return {
        'Method':         name,
        'Brier Score':    round(brier_score_loss(y_true, y_score), 4),
        'AUC-ROC':        round(roc_auc_score(y_true, y_score), 4),
        'AUC-PR':         round(average_precision_score(y_true, y_score), 4),
        'Precision':      round(precision_score(y_true, y_pred, zero_division=0), 4),
        'Recall':         round(recall_score(y_true, y_pred, zero_division=0), 4),
        'F1':             round(f1_score(y_true, y_pred, zero_division=0), 4),
        'Correlation':    round(pearsonr(y_true, y_score)[0], 4),
    }


# ─────────────────────────────────────────────
# VISUALIZATION
# ─────────────────────────────────────────────

def plot_results(df, ss, di, cw, eq, single, results_df):
    fig = plt.figure(figsize=(16, 12), facecolor='#0d0d0d')
    fig.suptitle(
        'VERDICT WEIGHT™ — Synthetic Validation Results',
        color='white', fontsize=15, fontweight='bold', y=0.98
    )
    gs = gridspec.GridSpec(2, 3, figure=fig, hspace=0.45, wspace=0.35)

    PURPLE  = '#7F77DD'
    PURPLE2 = '#534AB7'
    GRAY    = '#444'
    WHITE   = '#e8e8e8'
    GREEN   = '#4ade80'
    RED     = '#f87171'
    BG      = '#1a1a1a'

    def ax_style(ax, title):
        ax.set_facecolor(BG)
        ax.tick_params(colors=WHITE, labelsize=8)
        ax.set_title(title, color=WHITE, fontsize=9, fontweight='bold', pad=8)
        for spine in ax.spines.values():
            spine.set_color(GRAY)

    # 1. Score distributions
    ax1 = fig.add_subplot(gs[0, 0])
    ax_style(ax1, 'Score Distributions')
    ax1.hist(ss,     bins=40, alpha=0.7, color=PURPLE,  label='Signal Strength',    density=True)
    ax1.hist(eq,     bins=40, alpha=0.5, color='#60a5fa', label='Equal Weight',     density=True)
    ax1.hist(single, bins=40, alpha=0.4, color='#fbbf24', label='Single Source',    density=True)
    ax1.legend(fontsize=7, labelcolor=WHITE, facecolor=BG, edgecolor=GRAY)
    ax1.set_xlabel('Score', color=WHITE, fontsize=8)
    ax1.set_ylabel('Density', color=WHITE, fontsize=8)

    # 2. Signal Strength vs Ground Truth
    ax2 = fig.add_subplot(gs[0, 1])
    ax_style(ax2, 'Signal Strength vs Ground Truth')
    colors = [GREEN if gt == 1 else RED for gt in df['ground_truth']]
    ax2.scatter(ss, df['ground_truth'] + np.random.normal(0, 0.02, len(ss)),
                c=colors, alpha=0.3, s=8)
    ax2.set_xlabel('Signal Strength', color=WHITE, fontsize=8)
    ax2.set_ylabel('Ground Truth (jittered)', color=WHITE, fontsize=8)
    from matplotlib.patches import Patch
    ax2.legend(handles=[
        Patch(color=GREEN, label='True Threat'),
        Patch(color=RED,   label='False/Noise')
    ], fontsize=7, labelcolor=WHITE, facecolor=BG, edgecolor=GRAY)

    # 3. Doubt Index by Profile
    ax3 = fig.add_subplot(gs[0, 2])
    ax_style(ax3, 'Doubt Index by Profile')
    profile_order = ['HIGH', 'MEDIUM', 'LOW', 'ADVERSARIAL', 'STALE']
    profile_colors = [GREEN, PURPLE, RED, '#fbbf24', '#60a5fa']
    data_by_profile = [df.loc[df['profile'] == p, :].index for p in profile_order]
    box_data = [di[idx] for idx in data_by_profile]
    bp = ax3.boxplot(box_data, patch_artist=True, notch=False)
    for patch, color in zip(bp['boxes'], profile_colors):
        patch.set_facecolor(color)
        patch.set_alpha(0.7)
    for element in ['whiskers', 'fliers', 'means', 'medians', 'caps']:
        plt.setp(bp[element], color=WHITE)
    ax3.set_xticklabels(profile_order, rotation=20, fontsize=7, color=WHITE)
    ax3.set_ylabel('Doubt Index', color=WHITE, fontsize=8)

    # 4. Performance comparison bar chart
    ax4 = fig.add_subplot(gs[1, 0])
    ax_style(ax4, 'Method Comparison — Key Metrics')
    metrics = ['Brier Score', 'AUC-ROC', 'F1', 'AUC-PR']
    methods = results_df['Method'].tolist()
    x = np.arange(len(metrics))
    width = 0.25
    bar_colors = [PURPLE, '#60a5fa', '#fbbf24']
    for i, (method, color) in enumerate(zip(methods, bar_colors)):
        vals = [results_df.loc[results_df['Method'] == method, m].values[0] for m in metrics]
        # Invert Brier score so lower = worse visually
        vals[0] = 1 - vals[0]
        bars = ax4.bar(x + i * width, vals, width, label=method,
                       color=color, alpha=0.8, edgecolor=GRAY)
    ax4.set_xticks(x + width)
    ax4.set_xticklabels(['1-Brier', 'AUC-ROC', 'F1', 'AUC-PR'], fontsize=8, color=WHITE)
    ax4.set_ylim(0, 1.05)
    ax4.legend(fontsize=7, labelcolor=WHITE, facecolor=BG, edgecolor=GRAY)
    ax4.set_ylabel('Score (higher = better)', color=WHITE, fontsize=8)

    # 5. Consequence Weight heatmap by profile
    ax5 = fig.add_subplot(gs[1, 1])
    ax_style(ax5, 'Consequence Weight — Mean by Profile')
    profile_means = []
    for p in profile_order:
        idx = df[df['profile'] == p].index
        profile_means.append(np.mean(cw[idx]))
    bars = ax5.barh(profile_order, profile_means, color=profile_colors, alpha=0.8, edgecolor=GRAY)
    ax5.set_xlim(0, 1.0)
    ax5.set_xlabel('Mean Consequence Weight', color=WHITE, fontsize=8)
    for bar, val in zip(bars, profile_means):
        ax5.text(val + 0.01, bar.get_y() + bar.get_height()/2,
                 f'{val:.3f}', va='center', color=WHITE, fontsize=8)

    # 6. Stats table
    ax6 = fig.add_subplot(gs[1, 2])
    ax6.set_facecolor(BG)
    ax6.axis('off')
    ax6.set_title('Full Results Table', color=WHITE, fontsize=9, fontweight='bold', pad=8)
    col_labels = ['Metric', 'VW™', 'Equal', 'Single']
    row_labels = ['Brier↓', 'AUC-ROC', 'AUC-PR', 'F1', 'Precision', 'Recall', 'Corr']
    metric_keys = ['Brier Score', 'AUC-ROC', 'AUC-PR', 'F1', 'Precision', 'Recall', 'Correlation']
    cell_data = []
    for mk, rl in zip(metric_keys, row_labels):
        row = [rl]
        for method in methods:
            val = results_df.loc[results_df['Method'] == method, mk].values[0]
            row.append(f'{val:.4f}')
        cell_data.append(row)
    table = ax6.table(
        cellText=cell_data,
        colLabels=col_labels,
        loc='center',
        cellLoc='center'
    )
    table.auto_set_font_size(False)
    table.set_fontsize(8)
    for (row, col), cell in table.get_celld().items():
        cell.set_facecolor('#1a1a1a' if row > 0 else '#2a2a2a')
        cell.set_text_props(color=PURPLE if col == 1 and row > 0 else WHITE)
        cell.set_edgecolor(GRAY)
        if col == 1 and row > 0:
            cell.set_text_props(color=PURPLE, fontweight='bold')
    table.scale(1, 1.6)

    plt.savefig('/mnt/user-data/outputs/verdict_weight_validation.png',
                dpi=180, bbox_inches='tight', facecolor='#0d0d0d')
    plt.close()


# ─────────────────────────────────────────────
# MAIN
# ─────────────────────────────────────────────

def main():
    print("=" * 60)
    print("  VERDICT WEIGHT™ SYNTHETIC VALIDATION ENGINE v2.1")
    print("  Odingard Security / Six Sense Enterprise Services")
    print("=" * 60)

    # Generate dataset
    print(f"\n[1/4] Generating synthetic dataset (N=1000)...")
    df = generate_synthetic_dataset(1000)
    print(f"      Scenarios generated: {len(df)}")
    print(f"      Ground truth positive rate: {df['ground_truth'].mean():.1%}")
    print(f"\n      Profile distribution:")
    for p, cnt in df['profile'].value_counts().items():
        tp_rate = df.loc[df['profile'] == p, 'ground_truth'].mean()
        print(f"        {p:12s} → {cnt:4d} scenarios | TP rate: {tp_rate:.1%}")

    # Score all scenarios
    print(f"\n[2/4] Running VERDICT WEIGHT™ and baselines...")
    SR = df['SR'].values
    CC = df['CC'].values
    TD = df['TD'].values
    HA = df['HA'].values

    ss, di, cw = verdict_weight(SR, CC, TD, HA)
    eq          = baseline_equal_weight(SR, CC, TD, HA)
    single      = baseline_single_source(SR)

    df['VW_Signal_Strength']   = ss
    df['VW_Doubt_Index']       = di
    df['VW_Consequence_Weight'] = cw
    df['Baseline_Equal']       = eq
    df['Baseline_Single']      = single

    # Evaluate
    print(f"\n[3/4] Computing evaluation metrics...")
    y_true = df['ground_truth'].values
    results = [
        evaluate(y_true, ss,     'VERDICT WEIGHT™'),
        evaluate(y_true, eq,     'Equal Weight'),
        evaluate(y_true, single, 'Single Source'),
    ]
    results_df = pd.DataFrame(results)

    print("\n" + "=" * 60)
    print("  RESULTS")
    print("=" * 60)
    print(results_df.to_string(index=False))

    # Improvement summary
    vw_brier = results_df.loc[results_df['Method'] == 'VERDICT WEIGHT™', 'Brier Score'].values[0]
    eq_brier = results_df.loc[results_df['Method'] == 'Equal Weight',    'Brier Score'].values[0]
    si_brier = results_df.loc[results_df['Method'] == 'Single Source',   'Brier Score'].values[0]

    vw_auc = results_df.loc[results_df['Method'] == 'VERDICT WEIGHT™', 'AUC-ROC'].values[0]
    eq_auc = results_df.loc[results_df['Method'] == 'Equal Weight',    'AUC-ROC'].values[0]
    si_auc = results_df.loc[results_df['Method'] == 'Single Source',   'AUC-ROC'].values[0]

    print(f"\n  VERDICT WEIGHT™ vs Equal Weight:")
    print(f"    Brier Score improvement:  {((eq_brier - vw_brier) / eq_brier * 100):+.1f}%")
    print(f"    AUC-ROC improvement:      {((vw_auc - eq_auc) / eq_auc * 100):+.1f}%")

    print(f"\n  VERDICT WEIGHT™ vs Single Source:")
    print(f"    Brier Score improvement:  {((si_brier - vw_brier) / si_brier * 100):+.1f}%")
    print(f"    AUC-ROC improvement:      {((vw_auc - si_auc) / si_auc * 100):+.1f}%")

    # Profile-level analysis
    print(f"\n  ADVERSARIAL profile detection (critical case):")
    adv_idx = df[df['profile'] == 'ADVERSARIAL'].index
    adv_vw  = ss[adv_idx].mean()
    adv_eq  = eq[adv_idx].mean()
    adv_si  = single[adv_idx].mean()
    print(f"    VERDICT WEIGHT™ mean score: {adv_vw:.3f}")
    print(f"    Equal Weight mean score:    {adv_eq:.3f}")
    print(f"    Single Source mean score:   {adv_si:.3f}")
    print(f"    → VW penalizes spoofed intel by {((adv_si - adv_vw)/adv_si*100):.1f}% vs single source")

    # Save outputs
    print(f"\n[4/4] Saving outputs...")
    df.to_csv('/mnt/user-data/outputs/verdict_weight_dataset.csv', index=False)
    results_df.to_csv('/mnt/user-data/outputs/verdict_weight_results.csv', index=False)
    plot_results(df, ss, di, cw, eq, single, results_df)

    print(f"\n  Files written:")
    print(f"    verdict_weight_dataset.csv   — full synthetic dataset (1000 scenarios)")
    print(f"    verdict_weight_results.csv   — evaluation metrics table")
    print(f"    verdict_weight_validation.png — publication-ready figure")
    print(f"\n{'=' * 60}")
    print(f"  VALIDATION COMPLETE. Ready for arXiv cs.CR submission.")
    print(f"{'=' * 60}\n")


if __name__ == '__main__':
    main()
