"""
VERDICT WEIGHT™ — Weight Ablation Study
Find the optimal stream weights via grid search + cross-validation
"""
import numpy as np
import pandas as pd
from sklearn.metrics import brier_score_loss, roc_auc_score, average_precision_score
from itertools import product
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import warnings
warnings.filterwarnings('ignore')

np.random.seed(42)

# Reuse dataset generator and scoring from main engine
TEMPORAL_DECAY_LAMBDA = 0.05
DOUBT_PENALTY = 0.30

def temporal_decay(age_days):
    return np.exp(-TEMPORAL_DECAY_LAMBDA * age_days)

def corroboration_score(n_sources):
    return 1.0 - np.exp(-0.55 * n_sources)

def signal_strength_custom(SR, CC, TD, HA, w):
    epsilon = 1e-9
    return np.clip(
        (SR+epsilon)**w[0] * (CC+epsilon)**w[1] *
        (TD+epsilon)**w[2] * (HA+epsilon)**w[3], 0, 1
    )

def doubt_index(SR, CC, TD, HA):
    streams = np.stack([SR, CC, TD, HA], axis=1)
    mean = np.mean(streams, axis=1)
    std  = np.std(streams, axis=1)
    DI   = np.where(mean > 1e-9, std / mean, 1.0)
    return np.clip(DI / 1.0, 0.0, 1.0)

def consequence_weight(SS, DI):
    return np.clip(SS * (1.0 - DOUBT_PENALTY * DI), 0, 1)

def generate_dataset(n=800):
    profiles = {'HIGH':200,'MEDIUM':240,'LOW':160,'ADVERSARIAL':120,'STALE':80}
    rows = []
    for profile, count in profiles.items():
        for _ in range(count):
            if profile == 'HIGH':
                sr=np.random.beta(9,2); age=np.random.exponential(3)
                ns=np.random.randint(3,8); ha=np.random.beta(8,2); tp=0.88
            elif profile == 'MEDIUM':
                sr=np.random.beta(4,3); age=np.random.exponential(10)
                ns=np.random.randint(1,5); ha=np.random.beta(4,3); tp=0.58
            elif profile == 'LOW':
                sr=np.random.beta(2,6); age=np.random.exponential(25)
                ns=np.random.randint(0,3); ha=np.random.beta(2,5); tp=0.18
            elif profile == 'ADVERSARIAL':
                sr=np.random.beta(8,2); age=np.random.exponential(5)
                ns=np.random.randint(0,2); ha=np.random.beta(3,4); tp=0.35
            else:
                sr=np.random.beta(7,2); age=np.random.exponential(45)
                ns=np.random.randint(2,6); ha=np.random.beta(7,2); tp=0.50
            td=temporal_decay(np.array([age]))[0]
            cc=corroboration_score(np.array([ns]))[0]
            rows.append({'profile':profile,
                'SR':np.clip(sr,0.01,0.99),'CC':np.clip(cc,0.01,0.99),
                'TD':np.clip(td,0.01,0.99),'HA':np.clip(ha,0.01,0.99),
                'ground_truth':int(np.random.random()<tp)})
    return pd.DataFrame(rows).sample(frac=1,random_state=42).reset_index(drop=True)

def evaluate_weights(df, w):
    SR=df['SR'].values; CC=df['CC'].values
    TD=df['TD'].values; HA=df['HA'].values
    y=df['ground_truth'].values
    ss=signal_strength_custom(SR,CC,TD,HA,w)
    di=doubt_index(SR,CC,TD,HA)
    cw=consequence_weight(ss,di)
    # Combined score: weighted sum of calibration + discrimination
    brier=brier_score_loss(y,cw)
    auc=roc_auc_score(y,cw)
    apr=average_precision_score(y,cw)
    # Also check adversarial suppression
    adv_idx=df[df['profile']=='ADVERSARIAL'].index
    adv_penalty = ss[adv_idx].mean()  # lower = better suppression
    composite = (1-brier)*0.35 + auc*0.35 + apr*0.20 + (1-adv_penalty)*0.10
    return composite, brier, auc, apr, adv_penalty

print("Running weight ablation study...")
print("Grid searching over all weight combinations (sum=1.0, step=0.05)\n")

df = generate_dataset(800)
step = 0.05
best_score = -1
best_weights = None
results = []

weight_range = np.arange(0.10, 0.55, step)
count = 0
for w0 in weight_range:
    for w1 in weight_range:
        for w2 in weight_range:
            w3 = 1.0 - w0 - w1 - w2
            if not (0.10 <= w3 <= 0.55):
                continue
            w = (w0, w1, w2, w3)
            composite, brier, auc, apr, adv = evaluate_weights(df, w)
            results.append({
                'W_SR':round(w0,2),'W_CC':round(w1,2),
                'W_TD':round(w2,2),'W_HA':round(w3,2),
                'Composite':round(composite,5),
                'Brier':round(brier,5),'AUC':round(auc,5),
                'APR':round(apr,5),'Adv_Score':round(adv,5)
            })
            count += 1
            if composite > best_score:
                best_score = composite
                best_weights = w

print(f"Combinations evaluated: {count}")
print(f"\n{'='*55}")
print(f"  OPTIMAL WEIGHTS FOUND")
print(f"{'='*55}")
print(f"  W_SR (Source Reliability):        {best_weights[0]:.2f}")
print(f"  W_CC (Cross-Feed Corroboration):  {best_weights[1]:.2f}")
print(f"  W_TD (Temporal Decay):            {best_weights[2]:.2f}")
print(f"  W_HA (Historical Accuracy):       {best_weights[3]:.2f}")
print(f"  ─────────────────────────────────────")
print(f"  Composite Score: {best_score:.5f}")

res_df = pd.DataFrame(results).sort_values('Composite', ascending=False)
print(f"\nTop 10 weight configurations:")
print(res_df.head(10).to_string(index=False))

# Compare original vs optimal
orig = (0.35, 0.25, 0.20, 0.20)
orig_composite, orig_brier, orig_auc, orig_apr, orig_adv = evaluate_weights(df, orig)
opt_composite,  opt_brier,  opt_auc,  opt_apr,  opt_adv  = evaluate_weights(df, best_weights)

print(f"\n{'='*55}")
print(f"  ORIGINAL vs OPTIMAL COMPARISON")
print(f"{'='*55}")
print(f"  {'Metric':<25} {'Original':>10} {'Optimal':>10} {'Delta':>10}")
print(f"  {'-'*55}")
print(f"  {'Composite Score':<25} {orig_composite:>10.4f} {opt_composite:>10.4f} {opt_composite-orig_composite:>+10.4f}")
print(f"  {'Brier Score (lower=better)':<25} {orig_brier:>10.4f} {opt_brier:>10.4f} {opt_brier-orig_brier:>+10.4f}")
print(f"  {'AUC-ROC':<25} {orig_auc:>10.4f} {opt_auc:>10.4f} {opt_auc-orig_auc:>+10.4f}")
print(f"  {'AUC-PR':<25} {orig_apr:>10.4f} {opt_apr:>10.4f} {opt_apr-orig_apr:>+10.4f}")
print(f"  {'Adv Intel Score (lower=better)':<25} {orig_adv:>10.4f} {opt_adv:>10.4f} {opt_adv-orig_adv:>+10.4f}")

# Heatmap: SR vs CC for best TD/HA
fig, axes = plt.subplots(1, 2, figsize=(14, 5), facecolor='#0d0d0d')
fig.suptitle('VERDICT WEIGHT™ — Weight Ablation Heatmaps', color='white', fontsize=13, fontweight='bold')

for ax, metric, title in zip(axes, ['Composite','AUC'], ['Composite Score','AUC-ROC']):
    pivot_data = res_df.pivot_table(values=metric, index='W_SR', columns='W_CC', aggfunc='max')
    im = ax.imshow(pivot_data.values, cmap='RdPu', aspect='auto', origin='lower')
    ax.set_xticks(range(len(pivot_data.columns)))
    ax.set_yticks(range(len(pivot_data.index)))
    ax.set_xticklabels([f'{v:.2f}' for v in pivot_data.columns], fontsize=7, color='white', rotation=45)
    ax.set_yticklabels([f'{v:.2f}' for v in pivot_data.index], fontsize=7, color='white')
    ax.set_xlabel('W_CC (Corroboration)', color='white', fontsize=9)
    ax.set_ylabel('W_SR (Source Reliability)', color='white', fontsize=9)
    ax.set_title(title, color='white', fontsize=10, fontweight='bold')
    ax.set_facecolor('#1a1a1a')
    plt.colorbar(im, ax=ax).ax.yaxis.set_tick_params(color='white')
    plt.setp(plt.getp(plt.colorbar(im, ax=ax).ax.axes, 'yticklabels'), color='white')

plt.tight_layout()
plt.savefig('/mnt/user-data/outputs/verdict_weight_ablation.png',
            dpi=180, bbox_inches='tight', facecolor='#0d0d0d')
plt.close()

res_df.to_csv('/mnt/user-data/outputs/verdict_weight_ablation.csv', index=False)
print(f"\nAblation complete. Files saved.")
